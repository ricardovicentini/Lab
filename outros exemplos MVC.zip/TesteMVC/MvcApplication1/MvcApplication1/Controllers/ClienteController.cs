﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class ClienteController : Controller
    {
        //
        // GET: /Cliente/

        public ActionResult Index()
        {

            var context = new DataClasses1DataContext();
            var clientes = from c in context.ClienteOEs
                           select c;
            
            return View(clientes);
        }

        //
        // GET: /Cliente/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Cliente/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Cliente/Create

        [HttpPost]
        public ActionResult Create(string nome, string email, string status)
        {
            try
            {
                
                bool stat = bool.TryParse(status, out stat)? stat : false;
                
                var context = new DataClasses1DataContext();
                var client = new ClienteOE {  Nome = nome, email = email, status = stat };
                context.ClienteOEs.InsertOnSubmit(client);
                context.SubmitChanges();
                return RedirectToAction("Index", context.ClienteOEs);
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /Cliente/Edit/5
 
        [HttpPost]
        public ActionResult Edit(string id,string nome, string email, string status)
        {
            int _id = 0;
            if (!int.TryParse(id,out _id) )
                throw new Exception("Id inválido");
            bool _status = bool.TryParse(status,out _status)?_status : false;
            var context = new DataClasses1DataContext();
            var cliente = (from c in context.ClienteOEs
                          where c.id == _id
                          select c).First();
            cliente.Nome = nome;
            cliente.email = email;
            cliente.status = _status;
            
            context.SubmitChanges();
            return View();
        }

        //
        // POST: /Cliente/Edit/5

        
        public ActionResult Edit(string id)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Cliente/Delete/5

        [HttpPost]
        public ActionResult Delete(int id)
        {
            var context = new DataClasses1DataContext();
            var clientes = from c in context.ClienteOEs
                                where c.id == id
                                select c;
            context.ClienteOEs.DeleteAllOnSubmit(clientes);
            context.SubmitChanges();
            return View();
        }

       
    }
}

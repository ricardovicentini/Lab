﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RemoteControl;

namespace RemoteControlTest
{
    class Program
    {
        static void Main(string[] args)
        {
            SimpleRemoteControl remote = new SimpleRemoteControl();
            //Light _light = new Light();
            //LightOnCommand lightOn = new LightOnCommand(_light);
            //LightOffCommand lightOff = new LightOffCommand(_light);
            //remote.SetCommand(0,lightOn,lightOff);
            //remote.ButtonOnPressed(0);
            //remote.ButtonOffPressed(0);
            //remote.ButtonUndoPressed();

            //GarageDoor _garageDoor = new GarageDoor();
            //GarageDoorOpenCommand garageOpen = new GarageDoorOpenCommand(_garageDoor);
            //GarageDorCloseCommand garageClose = new GarageDorCloseCommand(_garageDoor);
            //remote.SetCommand(1,garageOpen,garageClose);
            //remote.ButtonOnPressed(1);
            //remote.ButtonOffPressed(1);
            //remote.ButtonUndoPressed();

            CeilingFan ceilingFan = new CeilingFan("living roon");
            CeilingFanHighCommand ceilingFanHigh = new CeilingFanHighCommand(ceilingFan);
            CeilingFanMediumCommand ceilingFanMed = new CeilingFanMediumCommand(ceilingFan);
            CeilingFanOffCommand ceilingFanOff = new CeilingFanOffCommand(ceilingFan);

            remote.SetCommand(0, ceilingFanMed, ceilingFanOff);
            remote.SetCommand(1, ceilingFanHigh, ceilingFanOff);

            remote.ButtonOnPressed(0);
            remote.ButtonOffPressed(0);
            remote.ButtonUndoPressed();

            remote.ButtonOnPressed(1);
            remote.ButtonOffPressed(1);
            remote.ButtonUndoPressed();
            

        }
    }
}

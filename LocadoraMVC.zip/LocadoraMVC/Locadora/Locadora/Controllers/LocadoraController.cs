﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Locadora.Models;

namespace Locadora.Controllers
{
    public class LocadoraController : Controller
    {
        //
        // GET: /Locadora/

        public ActionResult Index()
        {
            var context = new DCLocadoraDataContext();
            var filmes = context.FilmeEOs;
            return View(filmes);
        }

        [HttpPost]
        public ActionResult Create(string filme, string genero, bool emprestado, string classific)
        {
            FilmeEO _filme = new FilmeEO() { Filme1 = filme, Genero = genero, flgEmprestado = emprestado, classificacao = classific };
            
            var context = new DCLocadoraDataContext();
            context.FilmeEOs.InsertOnSubmit(_filme);
            context.SubmitChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            var context = new DCLocadoraDataContext();
            
            var item = (from i in context.FilmeEOs
                        where i.Id == id
                        select i).First();

            context.FilmeEOs.DeleteOnSubmit(item);
            context.SubmitChanges();
            return RedirectToAction("Index");

        }

    }
}

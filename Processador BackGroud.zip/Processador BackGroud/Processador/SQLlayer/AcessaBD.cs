﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SQLlayer
{
    class AcessaBD
    {
        private SqlConnection _conexao;
        private SqlTransaction _transacao;

        public AcessaBD(string conexao)
        {
            _conexao = new SqlConnection(conexao);
            
        }

        public void AbreTransacao()
        {
            _conexao.Open();
            _transacao = _conexao.BeginTransaction();
        }

        public void CommitaTransacao()
        {
            _transacao.Commit();
            _conexao.Close();
            _conexao.Dispose();
        }

        public void CancelaTransacao()
        {
            _transacao.Rollback();
            _conexao.Close();
            _conexao.Dispose();
        }

        
        public void ExecutaComando(SqlCommand comando)
        {
            comando.Transaction = _transacao;
            comando.Connection = _conexao;
            comando.ExecuteNonQuery();
        }

    }
}

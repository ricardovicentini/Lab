﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class FibonattiIterator : iFibonacci
    {
        private static IEnumerable<int>
            Fibonatti(int nrItaracoes)
        {
            
            for(int i=0,a=0,b=0,c=1;i<=nrItaracoes;i++)
            {
                a = b + c;
                c = b;
                b = a;
                yield return a;
            }
            yield break;
        }

        public void RetornaFibonacci(int nrIteracoes_)
        {
            var t = Fibonatti(nrIteracoes_);
            Console.WriteLine(string.Join(", ", t));
        }
    }
}

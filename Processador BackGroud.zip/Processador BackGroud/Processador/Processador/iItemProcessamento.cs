﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProcessadorBG
{
    public abstract class ItemProcessamento
    {
        protected iProcessavel _processavel;
        public ItemProcessamento(iProcessavel processavel_)
        {
            _processavel = processavel_;
        }

        public iProcessavel Processavel
        {
            get { return _processavel; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class LightOnCommand : iCommand
    {
        Light _light;
        public LightOnCommand(Light light_)
        {
            this._light = light_;
        }
        public void Execute()
        {
            this._light.On();
        }


        public void Undo()
        {
            _light.Off();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class GarageDoorOpenCommand : iCommand
    {
        GarageDoor _garageDoor;
        
        public GarageDoorOpenCommand(GarageDoor garageDoor_)
        {
            this._garageDoor = garageDoor_;
        }
        
        public void Execute()
        {
            _garageDoor.Up();
        }


        public void Undo()
        {
            throw new NotImplementedException();
        }
    }
}

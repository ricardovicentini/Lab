﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer
{
    public class HeatIndexDisplay : IObserver, IDisplayElement
    {
        ISubject weatherData;
        float heat;

        public HeatIndexDisplay(ISubject _weatherData)
        {
            weatherData = _weatherData;
            weatherData .RegisterObserver(this);
            
        }
        public void Update(float temp, float hmidity, float pressure)
        {
            heat = (temp * hmidity) / pressure;
            Display();
        }

        public void Display()
        {
            Console.WriteLine("Heat: " + heat); ;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OutroTeste
{
    public delegate void UpdatedEventHandler(object sender, EventArgs e);
    public class SomeController
    {
        public event UpdatedEventHandler Updated;

        public virtual void OnUpdated(EventArgs e)
        {
            if (Updated != null)
            {
                this.Updated(this, e);
            }
        }

        public void DoSomething()
        { 
            //do something
            this.OnUpdated(new EventArgs());
        }
    }

    
}

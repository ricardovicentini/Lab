﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class StereoOnWithCDCommand : iCommand
    {
        Stereo _stereo;
        public StereoOnWithCDCommand(Stereo stereo_)
        {
            _stereo = stereo_;
        }
        public void Execute()
        {
            _stereo.On();
            _stereo.SetCD();
            _stereo.SetVolume(7);
        }


        public void Undo()
        {
            throw new NotImplementedException();
        }
    }
}

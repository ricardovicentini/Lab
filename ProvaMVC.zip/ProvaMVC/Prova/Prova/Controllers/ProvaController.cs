﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Prova.Models;

namespace Prova.Controllers
{
    public class ProvaController : Controller
    {
        //
        // GET: /Prova/

        public ActionResult Index()
        {
            var context = new DcProvaDataContext();
            var provas = context.Provas;
            return View(provas);
        }

        [HttpPost]
        public ActionResult Create(string descricao, bool ativo)
        {
            
            Prova.Models.Prova prova = new Prova.Models.Prova {  Descricao = descricao, flgAtivo = ativo };
            var context = new DcProvaDataContext();
            context.Provas.InsertOnSubmit(prova);
            context.SubmitChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Delete(int? id)
        {
            var context = new DcProvaDataContext();
            
            var item = (from o in context.Provas
                        where o.Id == id
                        select o).First();

            context.Provas.DeleteOnSubmit(item);
            context.SubmitChanges();
            return RedirectToAction("Index");

        }

        [HttpPost]
        public ActionResult Update(int id, string descricao, bool ativo)
        {
            var context = new DcProvaDataContext();
            var item = (from o in context.Provas
                        where o.Id == id
                        select o).First();
            item.Descricao = descricao;
            item.flgAtivo = ativo;
            
            context.SubmitChanges();

            return RedirectToAction("Index");
        }
    }
}

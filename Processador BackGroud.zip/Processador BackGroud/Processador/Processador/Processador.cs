﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProcessadorBG
{
    public class Processador
    {
        private static ItemProcessamento _itemProcessamento;

        public Processador(ItemProcessamento itemProcessamento_)
        {
            _itemProcessamento = itemProcessamento_;
        }

        public ItemProcessamento ItemProcessamento
        { 
            get {return  _itemProcessamento;}
        }

        public static void CancelaProcessamento()
        {
            _itemProcessamento.Processavel.Cancelar();
        }
    }
}

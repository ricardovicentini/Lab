﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public class ChicagoPizzaStore : PizzaStore
    {
        public override iPizza CreatePizza(string item)
        {
            switch (item)
            {
                case "chesse":
                    return new CHStyleChessePizza();
                case "veggie":
                    return new CHStyleVeggiePizza();
                case "clam":
                    return new CHStyleClamPizza();
                case "peperoni":
                    return new CHStylepeperoniPizza();
                default:
                    throw new Exception("Pizza não encontrada");
            }
        }

        public override Pizza CreatePizzaV2(string type)
        {
            throw new NotImplementedException();
        }
    }
}

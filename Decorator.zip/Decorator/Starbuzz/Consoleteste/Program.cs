﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Starbuzz;

namespace Consoleteste2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Beverage beverage = new Expresso();
            beverage.Size = EnumSize.medium;
            Console.WriteLine(string.Format("Bebida: {0}. custo: {1}",beverage.Description,beverage.Cost()));

            Beverage beverage2 = new DarkRoast();
            beverage2.Size = EnumSize.large;
            beverage2 = new Mocha(beverage2);
            beverage2 = new Mocha(beverage2);
            beverage2 = new Whip(beverage2);

            Console.WriteLine(string.Format("Bebida: {0}. custo: {1}", beverage2.Description, beverage2.Cost()));

            Beverage beverage3 = new HouseBlend();
            beverage3 = new Soy(beverage3);
            beverage3 = new Mocha(beverage3);
            beverage3 = new Whip(beverage3);

            Console.WriteLine(string.Format("Bebida: {0}. custo: {1}", beverage3.Description, beverage3.Cost()));

        }
    }
}

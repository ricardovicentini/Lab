﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public interface PizzaIngredientFactory
    {
        Douhg CreateDough();
        Sauce CreateSauce();
        Cheese CreateCheese();
        Veggie[] CreateVegies();
        Pepperoni CreatePepperoni();
        Clam CreateClam();
    }
}

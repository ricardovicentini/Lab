﻿using System;
using System.Threading;

namespace Threads
{
    public class Alpha
    { 
        //this method will be called when the thread starts
        public void Beta()
        {
            while (true)
            {
                Console.WriteLine("Alpha.Beta is running in its own thread");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Thread Start/Stop/Join Sample");

            Alpha oAlpha = new Alpha();

            //Create the thread object, passing in the Alpha.Beta method
            //via threadStart delegate.  This does not start the thread.
            Thread oThread = new Thread(new ThreadStart(oAlpha.Beta));

            //start the thread
            oThread.Start();

            //spin for a while waiting for the started thread to became alive
            while (!oThread.IsAlive);

            //put the main thread to sleep to allow oThread to do some work
            Thread.Sleep(1);

            //Request that oThrat be stopped
            oThread.Abort();

            //Wait oThread finishes . join also has overloads that take milliseconds interval or a timespan object
            oThread.Join();

            Console.WriteLine();
            Console.WriteLine("Alpha.Beta has finished");

            try
            {
                Console.WriteLine("Try to restart the Alpha.Beta thread");
                oThread.Start();
            }
            catch (ThreadStateException)
            {
                Console.Write("ThreadStateException trying to restart Alpha.Beta. ");
                Console.WriteLine("Expected since aborted threads cannot be restarted.");
            }



            
        }
    }
}

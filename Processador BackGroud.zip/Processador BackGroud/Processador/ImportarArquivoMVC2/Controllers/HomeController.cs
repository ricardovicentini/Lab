﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProcessadorBG;
using ImportadorArquivo;

namespace ImportarArquivoMVC2.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Importador de Arquivos";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult EnviarArquivo(HttpPostedFileBase selFile)
        {
            Processador  procec;
            Session["procec"] =  procec = new Processador(new ImportaArquivo(new ArquivoCSV(selFile.InputStream)));
            string retorno = procec.ItemProcessamento.Processavel.Processar<string>();

            double tempo = ((ArquivoCSV)procec.ItemProcessamento.Processavel).ObterTempoProcessametno();
                        
            
            return Json(new {Sucesso = true,
                             Log = retorno,
                             TempoProcessamento = tempo
                            }
                        );
        }

        public ActionResult ObterStatus()
        {
            
            var status = Json(new
            {
                TotalLinhas = ArquivoCSV.TotalLinhas,
                LinhasProcessadas = ArquivoCSV.LinhasProcessadas,
                LinhasProcSucesso = ArquivoCSV.LinhasProcSucesso,
                LinhasProcErro = ArquivoCSV.LinhasProcErro,
                PercentProcessado = ArquivoCSV.ObtemPercentualProcessado()

            });
            
            
            return status;
        }

        public void CancelarImportacao()
        {
            Processador.CancelaProcessamento();            
        }
    }
}

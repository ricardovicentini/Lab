﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class FibonacciSimples : iFibonacci
    {
        

        public void RetornaFibonacci(int nrIteracoes)
        {
            int atual = 1;
            int ultimo = atual;
            int penultimo = 0;
            Console.Write(atual + ",");
            for (int i = 0; i <= nrIteracoes; i++)
            {
                atual = ultimo + penultimo;
                penultimo = ultimo;
                ultimo = atual;
                Console.Write(string.Format("{0},",atual));
            }
        }
    }
}

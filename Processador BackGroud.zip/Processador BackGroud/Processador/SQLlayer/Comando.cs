﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SQLlayer
{
    public class Comando 
    {
        AcessaBD bd;
        public Comando(string stringConexao) 
        {
            bd = new AcessaBD(stringConexao);

        }

        public void AbreTransacao()
        {
            bd.AbreTransacao();
        }

        public void EfetivaTransacao()
        {
            bd.CommitaTransacao();
        }

        public void CancelaTransacao()
        {
            bd.CancelaTransacao();
        }

        
        public void InsereProduto(double linha, string descCurta, string desc, decimal valor)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "linha", Value = linha });
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "DescCurta", Value = descCurta });
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "Desc", Value = desc});
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "Valor", Value = valor });
            cmd.CommandText = "InsereProduto";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            bd.ExecutaComando(cmd);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public abstract class PizzaStore
    {
        public iPizza orderPizza(string type) {
            iPizza pizza;
            pizza = CreatePizza(type);
            pizza.prepare();
            pizza.bake();
            pizza.cut();
            pizza.box();
            return pizza;
        }

        public abstract iPizza CreatePizza(string type);

        public abstract Pizza CreatePizzaV2(string type);
    }

    
}

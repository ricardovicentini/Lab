﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dotNetObserver
{
    public class CurrentPressure : DisplayElement, IObserver
    {
        private float _temperature;
        private float _humididty;
        private float _pressure;

        WeatherData _wd;
        public CurrentPressure(WeatherData wd)
        {
            _wd = wd;
            _wd.MesurementChanged += new MesurementChangedEventHandler(_wd_MesurementChanged);
        }

        void _wd_MesurementChanged(float temperature, float humidity, float pressure)
        {
            _temperature = temperature;
            _humididty = humidity;
            _pressure = pressure;
            Display();
            
        }

        

        public void Display()
        {
            Console.WriteLine("pressure: " + _pressure);
        }

        public void Upadte(float temperature, float humidity, float pressure)
        {
            _wd_MesurementChanged(temperature, humidity, pressure);
        }
    }
}

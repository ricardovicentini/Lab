﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public interface iPizza
    {
        void prepare();
        void bake();
        void cut();
        void box();

    }

    public abstract class Pizza 
    {
        string _nome;
        public Douhg _dough;
        public Sauce _sauce;
        public Veggie[] _veggies;
        public Cheese _cheese;
        public Pepperoni _pepperoni;
        public Clam _clam;

        public abstract void Prepare();

        private void Bake()
        {
            Console.WriteLine("Bake for 30 min");
        }

        private void Cut()
        {
            Console.WriteLine("Cut in diagonal slices");
        }

        private void box()
        {
            Console.WriteLine("Colocado na caixa");
        }

        public string Name { get; set; }
    }
    

    public class NYStyleChessePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("NY Pizza de queijo preparada");
        }

        public void bake()
        {
            Console.WriteLine(" NY Pizza de queijo assada");
        }

        public void cut()
        {
            Console.WriteLine("NY Pizza de queijo cortada");
        }

        public void box()
        {
            Console.WriteLine("NY Pizza de queijo embalada"); 
        }
    }

    public class NYStyleVeggiePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("NY Pizza de vegetais preparada");
        }

        public void bake()
        {
            Console.WriteLine(" NY Pizza de vegetais assada");
        }

        public void cut()
        {
            Console.WriteLine("NY Pizza de vegetais cortada");
        }

        public void box()
        {
            Console.WriteLine("NY Pizza de vegetais embalada");
        }
    }

    public class NYStyleClamPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("NY Pizza de mariscos preparada");
        }

        public void bake()
        {
            Console.WriteLine(" NY Pizza de mariscos assada");
        }

        public void cut()
        {
            Console.WriteLine("NY Pizza de mariscos cortada");
        }

        public void box()
        {
            Console.WriteLine("NY Pizza de mariscos embalada");
        }
    }

    public class NYStylepeperoniPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("NY Pizza de peperoni preparada");
        }

        public void bake()
        {
            Console.WriteLine(" NY Pizza de peperoni assada");
        }

        public void cut()
        {
            Console.WriteLine("NY Pizza de peperoni cortada");
        }

        public void box()
        {
            Console.WriteLine("NY Pizza de peperoni embalada");
        }
    }

    //--

    public class CHStyleChessePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CH Pizza de queijo preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CH Pizza de queijo assada");
        }

        public void cut()
        {
            Console.WriteLine("CH Pizza de queijo cortada");
        }

        public void box()
        {
            Console.WriteLine("CH Pizza de queijo embalada");
        }
    }

    public class CHStyleVeggiePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CH Pizza de vegetais preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CH Pizza de vegetais assada");
        }

        public void cut()
        {
            Console.WriteLine("CH Pizza de vegetais cortada");
        }

        public void box()
        {
            Console.WriteLine("CH Pizza de vegetais embalada");
        }
    }

    public class CHStyleClamPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CH Pizza de mariscos preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CH Pizza de mariscos assada");
        }

        public void cut()
        {
            Console.WriteLine("CH Pizza de mariscos cortada");
        }

        public void box()
        {
            Console.WriteLine("CH Pizza de mariscos embalada");
        }
    }

    public class CHStylepeperoniPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CH Pizza de peperoni preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CH Pizza de peperoni assada");
        }

        public void cut()
        {
            Console.WriteLine("CH Pizza de peperoni cortada");
        }

        public void box()
        {
            Console.WriteLine("CH Pizza de peperoni embalada");
        }
    }

    //--- California

    public class CAStyleChessePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CA Pizza de queijo preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CA Pizza de queijo assada");
        }

        public void cut()
        {
            Console.WriteLine("CA Pizza de queijo cortada");
        }

        public void box()
        {
            Console.WriteLine("CA Pizza de queijo embalada");
        }
    }

    public class CAStyleVeggiePizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CA Pizza de vegetais preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CA Pizza de vegetais assada");
        }

        public void cut()
        {
            Console.WriteLine("CA Pizza de vegetais cortada");
        }

        public void box()
        {
            Console.WriteLine("CA Pizza de vegetais embalada");
        }
    }

    public class CAStyleClamPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CA Pizza de mariscos preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CA Pizza de mariscos assada");
        }

        public void cut()
        {
            Console.WriteLine("CA Pizza de mariscos cortada");
        }

        public void box()
        {
            Console.WriteLine("CA Pizza de mariscos embalada");
        }
    }

    public class CAStylepeperoniPizza : iPizza
    {
        public void prepare()
        {
            Console.WriteLine("CA Pizza de peperoni preparada");
        }

        public void bake()
        {
            Console.WriteLine(" CA Pizza de peperoni assada");
        }

        public void cut()
        {
            Console.WriteLine("CA Pizza de peperoni cortada");
        }

        public void box()
        {
            Console.WriteLine("CA Pizza de peperoni embalada");
        }
    }

}

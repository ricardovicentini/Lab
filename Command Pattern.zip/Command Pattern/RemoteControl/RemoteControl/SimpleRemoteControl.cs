﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class SimpleRemoteControl
    {
        iCommand[] onCommands;
        iCommand[] offCommands;
        iCommand undo;
        public SimpleRemoteControl() 
        {
            onCommands = new iCommand[7];
            offCommands = new iCommand[7];
        }

        public void SetCommand(int idSlot, iCommand oncommand_, iCommand offCommand_)
        {
            onCommands[idSlot] = oncommand_;
            offCommands[idSlot] = offCommand_;
        }

        public void ButtonOnPressed(int idSlot)
        {
            onCommands[idSlot].Execute();
            undo = onCommands[idSlot];
        }

        public void ButtonOffPressed(int idSlot)
        {
            offCommands[idSlot].Execute();
            undo = offCommands[idSlot];
        }

        public void ButtonUndoPressed()
        {
            undo.Undo();
        }
    }
}

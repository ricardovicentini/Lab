﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer
{
    public interface ISubject
    {
        void RegisterObserver(iObserver observer);
        void RemoveObserver(iObserver observer);
        void notifyObserver();
    }
}

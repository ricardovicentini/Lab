﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public class CheesePizza : Pizza
    {
        PizzaIngredientFactory ingrediantFactory;

        public CheesePizza(PizzaIngredientFactory _ingrediantFactory)
        {
            this.ingrediantFactory = _ingrediantFactory;
            
        }
        public override void Prepare()
        {
            _dough = ingrediantFactory.CreateDough();
            _sauce = ingrediantFactory.CreateSauce();
            _cheese = ingrediantFactory.CreateCheese();
        }
    }
}

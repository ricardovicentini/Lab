﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace LambdaExpressions
{
    class Program
    {
        public class Funcionario
        {
            public int Codigo { get; set; }
            public string Nome { get; set; }
            public Int64 Fone { get; set; }
            public decimal Salario { get; set; }
        }
        
        static void Main(string[] args)
        {
            Func<int, bool> myFunc = x => x == 5;
            bool result = myFunc(4);

            int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0,15,13,47 };
            int impares = numbers.Count( x => x % 2 == 1);
            int pares = numbers.Count(x => x % 2 == 0);
            var firstnumberslessthen6 = numbers.TakeWhile(x => x < 6);
            var firstLargerThanIndexNumbers = numbers.TakeWhile((x, index) => x >= index);
        }
    }
}

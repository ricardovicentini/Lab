﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class FibonattiArray : iFibonacci
    {
        public void RetornaFibonacci(int nrIteracoes)
        {
            int[] items = new int[nrIteracoes];
            items[0] = 1;
            items[1] = 1;
            for (int i = 2; i < nrIteracoes; i++)
            {
                items[i] = items[i - 1] + items[i - 2];
            }

            Console.WriteLine( string.Join(",", items));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Starbuzz
{
    public enum EnumSize
    { 
        small,
        medium,
        large
    }
    public abstract class Beverage
    {

        public string Description {get;set;}
        public EnumSize Size { get; set; } 

        public abstract double Cost();
    }

    public abstract class CondimentDecorator : Beverage
    {
        //public string Description { get; set; }

        
    }

    public class Expresso : Beverage
    {
        public Expresso()
        {
            Description = "Expressso";
            Size = EnumSize.small;
        }

        public override double Cost()
        {
            double value = 0;
            switch (Size)
            {
                case EnumSize.small:
                    value = .10;
                    break;
                case EnumSize.medium:
                    value = .15;
                    break;
                case EnumSize.large:
                    value = .20;
                    break;
            }

            return value + 1.99;
        }
    }

    public class HouseBlend : Beverage
    {
        public HouseBlend()
        {
            Description = "Hose Blend Coffee";
            Size = EnumSize.small;
        }
        public override double Cost()
        {
            double value = 0;
            switch (Size)
            {
                case EnumSize.small:
                    value = .10;
                    break;
                case EnumSize.medium:
                    value = .15;
                    break;
                case EnumSize.large:
                    value = .20;
                    break;
            }

            return value + .99;
        }
    }

    public class DarkRoast : Beverage
    {
        public DarkRoast()
        {
            Description = "Dark Roast";
            Size = EnumSize.small;
        }
        public override double Cost()
        {
            double value = 0;
            switch (Size)
            {
                case EnumSize.small:
                    value = .10;
                    break;
                case EnumSize.medium:
                    value = .15;
                    break;
                case EnumSize.large:
                    value = .20;
                    break;
            }

            return value + 1.29;
        }
    }

    public class Mocha : CondimentDecorator
    {
        Beverage _beverage;
        public Mocha(Beverage beverage)
        {
            _beverage = beverage;
            Description = _beverage.Description + ", Mocha";
        }
        public override double Cost()
        {
            
            return .29 +  _beverage.Cost();
        }
    }

    public class Soy : CondimentDecorator
    {
        Beverage _beverage;
        public Soy(Beverage beverage)
        {
            _beverage = beverage;
            Description = _beverage.Description + ", Soy";
        }
        public override double Cost()
        {
            return .15 + _beverage.Cost();
        }
    }

    public class Whip : CondimentDecorator
    {
        Beverage _beverage;
        public Whip(Beverage beverage)
        {
            _beverage = beverage;
            Description = _beverage.Description + ", Whip";
        }

        public override double Cost()
        {
            return .19 + _beverage.Cost();
        }
    }
  
}

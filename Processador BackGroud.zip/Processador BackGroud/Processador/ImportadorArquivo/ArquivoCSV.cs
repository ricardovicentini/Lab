﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;
using SQLlayer;
using System.Globalization;
using System.Threading.Tasks;

namespace ImportadorArquivo
{
    public class ArquivoCSV : Arquivo
    {
        private static int _qtdTotalLinhas;
        private static int _qtdLinhasProcessadas;
        private static int _qtdLinhasProcSucesso;
        private static int _qtdLinhasProcErro;
        private static bool _cancelaOperacao = false;

        private double _tempoProcessamento;
        public double ObterTempoProcessametno()
        {
            return _tempoProcessamento;
        }


        public ArquivoCSV(Stream _fileStream): base(_fileStream)
        {
            _qtdTotalLinhas = 0;
            _qtdLinhasProcessadas = 0;
            _qtdLinhasProcSucesso = 0;
            _qtdLinhasProcErro = 0;
        }
    
        public static int TotalLinhas
        {
          
            get {return _qtdTotalLinhas;}
        }

        public static int LinhasProcessadas
        {
            get{return _qtdLinhasProcessadas;}
        }

        public static int LinhasProcSucesso
        {
             get { return _qtdLinhasProcSucesso;}
        }

        public static int LinhasProcErro
        {
            get {return _qtdLinhasProcErro;}
        }

        public static int ObtemPercentualProcessado()
        {
            
            
            return (int)Math.Round(((float)_qtdLinhasProcessadas / (float)_qtdTotalLinhas) * 100);
            
            
        }
        private void SomaLinhaProcessada()
        {
            lock (this)
            {
                _qtdLinhasProcessadas++;
            }
        }

        private void SomaLinhaProcSucesso()
        {
            lock (this)
            {
                _qtdLinhasProcSucesso++;
            }
        }

        private void SomaLinhaProcErro()
        {
            lock (this)
            {
                _qtdLinhasProcErro++;
            }
        }

        private string PorcessaLinha(string linha)
        {
            StringBuilder sb = new StringBuilder();

            Comando cmd = new Comando("Data Source=(local)\\sqlexpress;Initial Catalog=Produtos;Integrated Security=True");
            cmd.AbreTransacao();
            if (!_cancelaOperacao)
            {
                if (!_cancelaOperacao)
                {
                    SomaLinhaProcessada();

                    string[] colunas = linha.Split(';');

                    if (colunas.Length == 4)
                    {
                        //TODO: inserir no banco a linha
                        cmd.InsereProduto(double.Parse(colunas[0]), colunas[1], colunas[2], decimal.Parse(colunas[3], CultureInfo.GetCultureInfo("en-US")));
                        SomaLinhaProcSucesso();

                    }
                    else
                    {
                        sb.AppendLine(string.Format("linha {0} não contem o nr de colunas correto<br/>\n", _qtdLinhasProcessadas));
                        SomaLinhaProcErro();
                    }
                }
                else
                {
                    sb.AppendLine("Operacao cancelada");
                    cmd.CancelaTransacao();
                    return sb.ToString();
                }
            }
            cmd.EfetivaTransacao();

            return sb.ToString();
        }
        public override T Processar<T>()
        {
            long startTiks = DateTime.Now.Ticks;
            StringBuilder sb = new StringBuilder();

            string[] linhas = new StreamReader(FileStream).ReadToEnd().Split('\n');
            _qtdTotalLinhas = linhas.Length;


            #region "foreach"
            //foreach (string linha in linhas)
            //{
            //    sb.AppendLine(PorcessaLinha(linha));
            //}
            #endregion

            #region "Usando parallel.foreach"
            
            Parallel.ForEach(linhas, linha => sb.AppendLine(PorcessaLinha(linha)));
            #endregion

            #region "por thread"
            //int nrThreads = (int)(_qtdTotalLinhas * 0.00003) > 0 ? (int)(_qtdTotalLinhas * 0.00003) : 1;

            //int idxBase = _qtdTotalLinhas / nrThreads;
            //int idxStart = 0;

            //List<Thread> threads = new List<Thread>();

            //for (int i = 0; i < nrThreads; i++)
            //{
            //    //ultima passagem
            //    if (i == nrThreads - 1)
            //    {
            //        idxBase = linhas.Length;
            //    }

            //    int temp1 = idxStart;
            //    int temp2 = idxBase;
            //    threads.Add(new Thread(() => sb.AppendLine(ProcessaLinhas(linhas, temp1, temp2))));
            //    threads[i].Start();

            //    idxStart = idxBase;
            //    idxBase += idxBase;



            //}




            //foreach (Thread t in threads)
            //    t.Join();
#endregion

            long endTiks = DateTime.Now.Ticks;

            _tempoProcessamento = TimeSpan.FromTicks((endTiks - startTiks)).TotalSeconds;
            
            return (T) Convert.ChangeType( sb.ToString(),typeof(T));
        }

        private string ProcessaLinhas(string[] linhas, int idxInicio, int idxFim)
        {
            StringBuilder sb = new StringBuilder();

            Comando cmd = new Comando("Data Source=(local)\\sqlexpress;Initial Catalog=Produtos;Integrated Security=True");
            cmd.AbreTransacao();
            
            for (int i = idxInicio; i < idxFim && i < linhas.Length; i++)
            {
                if (!_cancelaOperacao)
                {
                    SomaLinhaProcessada();

                    string[] colunas = linhas[i].Split(';');

                    if (colunas.Length == 4)
                    {
                        //TODO: inserir no banco a linha
                        cmd.InsereProduto(double.Parse(colunas[0]), colunas[1], colunas[2],decimal.Parse(colunas[3],CultureInfo.GetCultureInfo("en-US")));
                        SomaLinhaProcSucesso();
                
                    }
                    else
                    {
                        sb.AppendLine(string.Format("linha {0} não contem o nr de colunas correto<br/>\n",i));
                        SomaLinhaProcErro();
                    }
                }
                else
                {
                    sb.AppendLine("Operacao cancelada");
                    cmd.CancelaTransacao();
                    return sb.ToString();
                }

            }

            cmd.EfetivaTransacao();

            return sb.ToString();
        }

        public override void Cancelar()
        {
            _cancelaOperacao = true;
        }
    }
}

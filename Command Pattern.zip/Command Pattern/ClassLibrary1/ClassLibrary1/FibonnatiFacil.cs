﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
   public  class FibonnatiFacil :iFibonacci
    {
        public void RetornaFibonacci(int nrIteracoes)
        {
            for (int i = 0, a = 0, b = 0, c = 1; i <= nrIteracoes; i++)
            {
                a = b + c;
                c = b;
                b = a;
                Console.Write(a +",");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer
{
    public class WeatherData : ISubject
    {
        List<IObserver> observers;
        float temperature;
        float humidity;
        float pressure;

        public  WeatherData()
        {
            observers = new List<IObserver>();
        }
        public void RegisterObserver(IObserver o)
        {
            observers.Add(o); 
        }

        public void RemoveObserver(IObserver o)
        {
            observers.Remove(o);
        }

        public void notifyObserver()
        {
            foreach (IObserver o in observers)
            {
                o.Update(temperature, humidity, pressure);
            }
        }

        public void MesurementChanged()
        {
            notifyObserver();
        }

        public void SetMesurements(float _temperature, float _humidity, float _pressure)
        {
            temperature = _temperature;
            humidity = _humidity;
            pressure = _pressure;
            MesurementChanged();
        }

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AgendaMVC.Models;

namespace AgendaMVC.Controllers
{
    public class AgendaController : Controller
    {
        //
        // GET: /Agenda/

        public ActionResult Index()
        {
            var context = new DCAgendaDataContext();
            var contatos = from c in context.ContatoOEs
                           select c;
            return View(contatos);
        }

        
       
        //
        // POST: /Agenda/Create

        [HttpPost]
        public ActionResult Create(string nome, string fone, string email)
        {
            try
            {
                
                var context = new DCAgendaDataContext();
                //var contatos = (from c in context.ContatoOEs
                //                select c);

                
                context.ContatoOEs.InsertOnSubmit(new ContatoOE { Nome = nome, email = email, Telefone = fone });
                context.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        
        //
        // GET: /Agenda/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Agenda/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, string nome, string fone, string email)
        {
            try
            {
                var context = new DCAgendaDataContext();
                var contato = (from c in context.ContatoOEs
                               where c.Id == id
                               select c).First();
                contato.Nome = nome;
                contato.Telefone = fone;
                contato.email = email;

                context.SubmitChanges();
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Agenda/Delete/5
 
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Agenda/Delete/5

        [HttpPost]
        public ActionResult Delete(int id)
        {
            try
            {
                var context = new DCAgendaDataContext();
                var contato = (from c in context.ContatoOEs
                              where c.Id == id
                              select c).First();

                context.ContatoOEs.DeleteOnSubmit(contato);
                context.SubmitChanges();
                 return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

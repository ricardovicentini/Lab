﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;

namespace Importador.Controllers
{
    public class ImportadorController : Controller
    {
        //
        // GET: /Importador/

        public ActionResult Index()
        {
            ViewData.Add(new KeyValuePair<string, object>("teste", 0));
            return View();
        }

        public ActionResult Send(HttpPostedFileBase file1)
        {
            ImportadorHelper.Importador importador = new ImportadorHelper.Importador();
            importador.ImportarArqvuivo(file1.InputStream, decimal.Parse(System.Configuration.ConfigurationManager.AppSettings["BaseLeitura"],CultureInfo.CurrentCulture));

            var Arquivo = 
                new { TempoProcessamento = ImportadorHelper.Importador.TempoProcessamento,
                      TotalLinhas = ImportadorHelper.Importador.TotalLinhas
                };

            return Json(Arquivo);
        }

        public ActionResult ObterStatus()
        { 
            var Arquivo = new {
                LinhasProcessadas = ImportadorHelper.Importador.LinhasProcessadas,
                PercentualProcessado = ImportadorHelper.Importador.ObterPercentualProcessado(),
                LinhasComErro = ImportadorHelper.Importador.ObterNrLinhasProcessadasErro,
                LinhasComSucesso = ImportadorHelper.Importador.ObterNrLinhasProcessadasSucesso
            };

            return Json(Arquivo);
        }
    }
}

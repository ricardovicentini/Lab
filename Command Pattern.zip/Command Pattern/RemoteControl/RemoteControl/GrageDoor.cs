﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class GarageDoor
    {
        public void Up()
        {
            Console.WriteLine("Door is up!");
        }

        public void Down()
        {
            Console.WriteLine("Door is down!");
        }

        public void Slop()
        {

            Console.WriteLine("Slop!");
        }

        public void lightOn()
        {
            Console.WriteLine("Garage light is on!");
        }

        public void lightOff()
        {
            Console.WriteLine("Garage light is off!");
        }
    }
}

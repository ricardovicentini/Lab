﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BibliotecaMVC.Models;
namespace BibliotecaMVC.Controllers
{
    public class LivroController : Controller
    {
        //
        // GET: /Livro/

        public ActionResult Index()
        {
            var contex = new DCBibliotecaDataContext();
            var livros = from dados in contex.LivroOEs
                         select dados;
            return View(livros.ToList());
        }

        
        [HttpPost]
        public ActionResult Create(string titulo, string autor, string preco)
        {
            decimal _preco = 0;
            if (!decimal.TryParse(preco, out _preco))
                throw new Exception("Preco Inválido");
            
            var livro = new LivroOE {  Titulo = titulo, Autor = autor, Preço = _preco };
            var context = new DCBibliotecaDataContext();
            context.LivroOEs.InsertOnSubmit(livro);
            context.SubmitChanges();
            return RedirectToAction("Index");
        } 

        //
        // POST: /Livro/Create

        
        
        //
        // GET: /Livro/Edit/5

        [HttpPost]
        public ActionResult Edit(string id, string titulo, string autor, string preco)
        {
            Int64 _id = 0;
            decimal _preco = 0;
            if (!Int64.TryParse(id, out _id))
                throw new Exception("Id do livro inválido");
            if(!decimal.TryParse(preco,out _preco))
                throw new Exception("preço inválido");
            var context = new DCBibliotecaDataContext();
            LivroOE livro = (from l in context.LivroOEs
                            where _id == l.ISBN
                            select l).First();
            livro.Titulo = titulo;
            livro.Autor = autor;
            livro.Preço = _preco;
            context.SubmitChanges();
            return RedirectToAction("Index");
        }

        

        //
        // GET: /Livro/Delete/5

        [HttpPost]
        public ActionResult Delete(int id)
        {
            var context = new DCBibliotecaDataContext();
            var livro = (from l in context.LivroOEs
                        where l.ISBN == id
                        select l).First();
            context.LivroOEs.DeleteOnSubmit(livro);
            context.SubmitChanges();
            return RedirectToAction("Index");
        }

        //
        // POST: /Livro/Delete/5

        
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using dotNetObserver;

namespace Console1
{
    class Program
    {
        static void Main(string[] args)
        {
            WeatherData wd = new WeatherData();
            List<IObserver> observers = new List<IObserver>();
            observers.Add(new CurrentTemperatureDisplay(wd));
            observers.Add(new CurrentPressure(wd));

            Random rd = new Random();
            while (Console.ReadKey().Key != ConsoleKey.Escape)
            {
                foreach (IObserver ob in observers)
                { 
                    ob.Upadte(rd.Next(-20, 40), rd.Next(0, 100), rd.Next(0, 100));
                }
                

            }
            
        }
    }
}

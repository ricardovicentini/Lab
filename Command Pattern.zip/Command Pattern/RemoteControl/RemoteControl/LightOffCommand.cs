﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class LightOffCommand : iCommand
    {
        Light _light;
        public LightOffCommand(Light light_)
        {
            _light = light_;
        }
        public void Execute()
        {
            _light.Off();
        }


        public void Undo()
        {
            _light.On();
        }
    }
}

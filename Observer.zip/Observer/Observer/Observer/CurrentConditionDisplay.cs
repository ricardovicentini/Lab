﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer
{
    public class CurrentConditionDisplay : IObserver, IDisplayElement
    {
        float temperature;
        float humidity;
        ISubject weatherData;

        public CurrentConditionDisplay(ISubject _weatherData)
        {
            weatherData = _weatherData;
            weatherData.RegisterObserver(this);
        }

        public void Update(float temp, float hmidity, float pressure)
        {
            temperature = temp;
            humidity = hmidity;
            Display();
        }

        public void Display()
        {
            Console.WriteLine(string.Format("Current conditions: {0} degrees, humidity: {1}",temperature,humidity)); 
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class CeilingFanHighCommand : iCommand
    {
        private CeilingFan _ceilingFan;
        int prevSpeed;

        public CeilingFanHighCommand(CeilingFan ceilingFan_)
        {
            this._ceilingFan = ceilingFan_;
        }
        public virtual void Execute()
        {
            prevSpeed = _ceilingFan.getSpeed();
            this._ceilingFan.High();
            Console.WriteLine("Ceiling Fan speed=" + CeilingFan.HIGH);
        }

        public void Undo()
        {
            switch (prevSpeed)
            { 
                case CeilingFan.HIGH:
                    _ceilingFan.High();
                    break;
                case CeilingFan.MEDIUM:
                    _ceilingFan.Medium();
                    break;
                case CeilingFan.LOW:
                    _ceilingFan.Low();
                    break;
                case CeilingFan.OFF:
                    _ceilingFan.Off();
                    break;
                
            }
            Console.WriteLine("Ceiling Fan speed=" + prevSpeed);
        }
    }

    public class CeilingFanMediumCommand : iCommand
    {
        CeilingFan _ceilingFan;
        int prevSpeed;

        public CeilingFanMediumCommand(CeilingFan ceilingFan_) 
        {
            _ceilingFan = ceilingFan_;
        }
        
        public void Execute()
        {
            prevSpeed = _ceilingFan.getSpeed();
            _ceilingFan.Medium();
            Console.WriteLine("Ceiling Fan speed=" + CeilingFan.MEDIUM);
        }


        public void Undo()
        {
            switch (prevSpeed)
            {
                case CeilingFan.HIGH:
                    _ceilingFan.High();
                    break;
                case CeilingFan.MEDIUM:
                    _ceilingFan.Medium();
                    break;
                case CeilingFan.LOW:
                    _ceilingFan.Low();
                    break;
                case CeilingFan.OFF:
                    _ceilingFan.Off();
                    break;

            }
            Console.WriteLine("Ceiling Fan speed=" + prevSpeed);
        }
    }

    public class CeilingFanLowCommand : iCommand
    {
        CeilingFan _ceilingFan;
        int prevSpeed;

        public CeilingFanLowCommand(CeilingFan ceilingFan_)
        {
            _ceilingFan = ceilingFan_;
        }

        public void Execute()
        {
            prevSpeed = _ceilingFan.getSpeed();
            _ceilingFan.Low();
        }


        public void Undo()
        {
            switch (prevSpeed)
            {
                case CeilingFan.HIGH:
                    _ceilingFan.High();
                    break;
                case CeilingFan.MEDIUM:
                    _ceilingFan.Medium();
                    break;
                case CeilingFan.LOW:
                    _ceilingFan.Low();
                    break;
                case CeilingFan.OFF:
                    _ceilingFan.Off();
                    break;

            }
            Console.WriteLine("Ceiling Fan speed=" + prevSpeed);
        }
    }

    public class CeilingFanOffCommand : iCommand
    {
        CeilingFan _ceilingFan;
        int prevSpeed;

        public CeilingFanOffCommand(CeilingFan ceilingFan_)
        {
            _ceilingFan = ceilingFan_;
        }

        public void Execute()
        {
            prevSpeed = _ceilingFan.getSpeed();
            _ceilingFan.Off();
            Console.WriteLine("Ceiling Fan speed=" + CeilingFan.OFF);
        }


        public void Undo()
        {
            switch (prevSpeed)
            {
                case CeilingFan.HIGH:
                    _ceilingFan.High();
                    break;
                case CeilingFan.MEDIUM:
                    _ceilingFan.Medium();
                    break;
                case CeilingFan.LOW:
                    _ceilingFan.Low();
                    break;
                case CeilingFan.OFF:
                    _ceilingFan.Off();
                    break;

            }
            Console.WriteLine("Ceiling Fan speed=" + prevSpeed);
        }
    }
}

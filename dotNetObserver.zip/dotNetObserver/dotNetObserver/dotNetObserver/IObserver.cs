﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dotNetObserver
{
    public interface IObserver
    {
        void Upadte(float temperature, float humidity, float pressure);
    }
}

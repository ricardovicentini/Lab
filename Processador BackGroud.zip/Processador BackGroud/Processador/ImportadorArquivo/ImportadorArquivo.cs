﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ProcessadorBG;

namespace ImportadorArquivo
{
    public class ImportaArquivo : ItemProcessamento
    {
        //private Arquivo _arquivo;

        public ImportaArquivo(Arquivo arquivo_): base(arquivo_){}
        

        public T ProcessaImportacao<T>()
        {
            return base._processavel.Processar<T>();
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Observer
{
    public class Monitor : ISubject
    {
        List<iObserver> dadosMonitorados;

        public Monitor()
        {
            dadosMonitorados = new List<iObserver>();
        }
        public void RegisterObserver(iObserver observer)
        {
            dadosMonitorados.Add(observer);
        }

        public void RemoveObserver(iObserver observer)
        {
            dadosMonitorados.Remove(observer);
        }

        public void notifyObserver()
        {
            foreach (iObserver o in dadosMonitorados)
            {
                o.update();
            }
        }

        public void MudouValor()
        {
            notifyObserver();
        }

        public void AtualizaValor()
        { 

        }
    }
}

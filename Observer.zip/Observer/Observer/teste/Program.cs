﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



namespace teste
{
    class Program
    {
        static void Main(string[] args)
        {
            Observer.WeatherData wd = new Observer.WeatherData();
            
            Observer.CurrentConditionDisplay ccd = new Observer.CurrentConditionDisplay(wd);
            Observer.HeatIndexDisplay hd = new Observer.HeatIndexDisplay(wd);

            int count = 0;
            while ( Console.ReadKey().Key != ConsoleKey.Escape)
            {
                Random rd = new Random();
                int temp = rd.Next(-20, 40);
                int press = rd.Next(0,100);
                int humid = rd.Next(0,100);
                wd.SetMesurements(temp , humid, press);

                count++;

                if (count >= 3)
                {
                    wd.RemoveObserver(ccd);
                }
            }
            
           
            
            
        }

        

        
    }
}

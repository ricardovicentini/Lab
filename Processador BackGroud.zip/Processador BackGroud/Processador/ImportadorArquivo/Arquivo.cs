﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ImportadorArquivo
{
    public abstract class Arquivo : ProcessadorBG.iProcessavel
    {
        private Stream fileStream;

        public Arquivo(Stream _fileStream)
        {
            fileStream = _fileStream;
        }

        public Stream FileStream
        {
            get { return fileStream; }
        }

        public abstract T Processar<T>();



        public abstract void Cancelar();
        
    }
}

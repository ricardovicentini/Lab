﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public class NYPizzaStore : PizzaStore
    {

        public override iPizza CreatePizza(string item)
        {
            
            
            switch (item){
                case "chesse":
                    return new NYStyleChessePizza();
                case "veggie":
                    return new NYStyleVeggiePizza();
                case "clam":
                    return new NYStyleClamPizza();
                case "peperoni":
                    return new NYStylepeperoniPizza();
                default:
                    throw new Exception("Pizza não encontrada");
            }
        }

        public override Pizza CreatePizzaV2(string item)
        {
            Pizza pizza = null;
            PizzaIngredientFactory ingredientFactory = new NYIngredientFactroy();
            switch (item)
            {
                case "cheese":
                    pizza = new CheesePizza(ingredientFactory);
                    pizza.Name = "Pizza de queijo";
                    break;
            }
            return pizza;

        }
    }
}

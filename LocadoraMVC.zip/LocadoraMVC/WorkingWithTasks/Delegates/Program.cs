﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace Delegates
{
    class Program
    {
        delegate int del(int i);
        delegate void Printer(string s);
        delegate int Calculador(int x, int y);

        static void DoWork(string s)
        {
            Console.WriteLine("do work: " + s);
        }

        static Calculador soma = delegate(int x, int y)
        {
            return x + y;
        };

        static void Main(string[] args)
        {
            del MyDelegate = x => x * x;
            
            
            int val = MyDelegate(5);

            MyDelegate = z => z + 20;

            val = MyDelegate(15);

            MyDelegate = delegate(int y) { return y - 5; };
            

            val = MyDelegate(7);

            Printer p = delegate(string s)
            {
                Console.WriteLine(s);
            };

            p("Ola");

            DoWork("Ola");

            p = new Printer(DoWork);
            p("Ola de novo");

           

            Calculador subt = delegate(int x, int y)
            {
                return x - y;
            };

            Calculador div = delegate(int x, int y)
            {
                return x / y;
            };

            val = soma(10, 4);
            val = subt(10, 4);
            val = div(7, 2);
            Expression<del> myEtT = x => x * x;
            
        }
    }
}

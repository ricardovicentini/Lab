﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class CeilingFan
    {
        public const int HIGH = 3;
        public const int MEDIUM = 2;
        public const int LOW = 1;
        public const int OFF = 0;
        string location;
        int speed;

        public CeilingFan(String location)
        {
            this.location = location;
            speed = OFF;
        }

        public void High()
        {
            speed = HIGH;
        }

        public void Medium()
        {
            speed = MEDIUM;
        }

        public void Low()
        {
            speed = LOW;
        }

        public void Off()
        {
            speed = OFF;
        }

        public int getSpeed()
        {
            return speed;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using SqlLayer;

namespace SqlComando
{
    public class Comando
    {
        private AcessoSql aSQL = new AcessoSql("Data Source=(local)\\sqlexpress;Initial Catalog=Produtos;Integrated Security=True");

        public void AbreTransacao()
        {
            
            aSQL.AbreTransacao();
        }
        public void FechaTransacao()
        {
            aSQL.ComitaTrasacao();
        }
        public void CancelaTransacao()
        {
            aSQL.Rollback();
        }
        public void InsereProduto(Int64 linha, string descricaoCurta, string descricao, decimal valor)
        {
            SqlCommand cmd = new SqlCommand();

            cmd.Parameters.Add(new SqlParameter() { ParameterName = "linha", Value = linha });
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "DescCurta", Value = descricaoCurta });
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "Desc", Value = descricao });
            cmd.Parameters.Add(new SqlParameter() { ParameterName = "Valor", Value = valor });
            cmd.CommandText = "InsereProduto";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            aSQL.ExecutaCommando(cmd);
            

        }
    }
}

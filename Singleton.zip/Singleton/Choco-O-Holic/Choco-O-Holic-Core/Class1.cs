﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Choco_O_Holic_Core
{
    public class ChocolateBoiler
    {
        private bool _empty;
        private bool _boiled;
        private static ChocolateBoiler _chocolateBoiler;

        public bool IsEmpty
        {
            get { return _empty; }
            set { _empty = value; }
        }

        public bool isBoiled
        {
            get { return _boiled; }
            set { _boiled = value; }
        }
        private ChocolateBoiler()
        {
            _empty = true;
            _boiled = false;    
        }

        public static ChocolateBoiler GetInstance()
        {

            if (_chocolateBoiler == null)
            {
                lock (_chocolateBoiler)
                {
                    _chocolateBoiler = new ChocolateBoiler();
                }
            }

            return _chocolateBoiler;
            
        }

        public void Fill()
        {
            if (_empty)
            {
                _empty = false;
                _boiled = false;
                //fil with milk/choco
            }
        }

        public void Drain()
        {
            if (!_empty && _boiled)
            {
                //drain the boiled milk / choco
                _empty = true;
            }
        }

        public void Boil()
        {
            if (!_empty && !_boiled)
            {
                //bring the contents to boil
                _boiled = true;
            }
        }
    }
}

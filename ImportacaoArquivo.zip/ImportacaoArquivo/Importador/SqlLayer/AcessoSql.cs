﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace SqlLayer
{
     
    public class AcessoSql
    {
        private SqlConnection _conexao;
        private SqlTransaction _trans;

        public AcessoSql(string strConexao)
        {
            _conexao = new SqlConnection(strConexao);
        }

        public void AbreTransacao()
        {
            _conexao.Open();
            _trans = _conexao.BeginTransaction();

        }

        public void Rollback()
        {
            _trans.Rollback();
            _conexao.Close();
            _conexao.Dispose();
        }
        public void ComitaTrasacao()
        {
            _trans.Commit();
            _conexao.Close();
            _conexao.Dispose();
        }

        public void ExecutaCommando(SqlCommand comando)
        {
            comando.Connection = _conexao;
            comando.Transaction = _trans;

            comando.ExecuteNonQuery();
        }
    }
}

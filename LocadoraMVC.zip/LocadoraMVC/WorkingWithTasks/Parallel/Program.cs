﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Programa
{
    
    class Program
    {
        

        static void Main(string[] args)
        {
            int[] input = { 4, 1, 6, 2, 9, 5, 10, 3 };
            int sum = 0;

            try
            {
                Parallel.ForEach(
                    input,
                    () => 0,
                    (n, loopState, localSum) =>
                    {
                        localSum += n;
                        Console.WriteLine("Thread={0}, n={1}, localSum={2}", Thread.CurrentThread.ManagedThreadId, n, localSum);
                        return localSum;

                    },
                    (localSum) => Interlocked.Add(ref sum, localSum)
                );
                
                Console.WriteLine(sum);
            }
            catch (AggregateException e)
            {
                Console.WriteLine("Parallel.ForEach has thrown an exception. THIS WAS NOT EXPECTED.\n{0}", e);
            }
            


        }
    }
}

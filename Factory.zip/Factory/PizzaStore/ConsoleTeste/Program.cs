﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PizzaStore;

namespace ConsoleTeste
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaStore.PizzaStore ps = new PizzaStore.NYPizzaStore();
            PizzaStore.Pizza pz = ps.CreatePizzaV2("cheese");
            pz.Prepare();
            Console.ReadKey();
            
        }
    }
}

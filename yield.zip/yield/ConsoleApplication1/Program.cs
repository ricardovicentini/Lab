﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibrary1;

namespace ConsoleApplication2
{
    class Produto
    {
        public int id {get;set;}
        public string descricao { get; set; }
        public decimal valor { get; set; }
    }

    class Program2
    {
        static IEnumerable<int>
            XPTO(int from, int to) {
                for (int i = from; i < to; i += 3) {
                    yield return i;
                }
                yield break;
        }

        static void conta()
        {
            int x = 100;
            int y = 200;
            x += x == 20 ? x / y : y / x;
            y -= y == 10 ? y / x : x / y;
        }
        static void Main(string[] args)
        {
            iFibonacci fib = new FibonacciSimples();
            fib.RetornaFibonacci(10);
            Console.WriteLine(" ");
            fib = new FibonattiArray();
            fib.RetornaFibonacci(10);
            Console.WriteLine(" ");
            fib = new FibonattiIterator();
            fib.RetornaFibonacci(5);

            fib = new FibonnatiFacil();
            fib.RetornaFibonacci(10);
            

            int[] vertor = { 1, 2, 3 };

            var produtos2 = new List<Produto>() { 
                new Produto { id = 1, descricao = "P1", valor = 10 }, 
                new Produto { id = 2, descricao = "P2", valor = 15 },
                new Produto { id = 2, descricao = "P3", valor = 20}};

            var oProdutos = new[] {new {id = 1, descricao = "P1", valor = 10 }, 
                           new {id = 2, descricao = "P2", valor = 15 },
                           new {id = 3, descricao = "P3", valor = 20 },
                           new {id = 3, descricao = "a4", valor = 20 },
                           new {id = 3, descricao = "A5 ddsdd", valor = 20 }};

            var produtosSelecionados = from p in oProdutos
                                       where p.valor >= 10 && p.valor <= 15
                                       select p;

            var produtosComA = oProdutos.Where(p => p.descricao.ToUpper().StartsWith("A"));
            
            //Console.WriteLine(string.Join(", ", XPTO(-10,10)));
            conta();
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dotNetObserver
{
    public delegate void MesurementChangedEventHandler(float temperature, float humidity, float pressure);
    public interface ISubject
    {
        event MesurementChangedEventHandler MesurementChanged;
        
    }
}

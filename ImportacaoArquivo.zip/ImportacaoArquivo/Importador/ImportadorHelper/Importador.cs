﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using SqlComando;
using System.Threading.Tasks;
using System.Threading;

namespace ImportadorHelper
{
    public class Importador
    {
        private static int nrTotalLinhas;
        private static int nrLinhasProcessadas;
        private static int nrLinhasProcessadasSucesso;
        private static int nrLinhasProcessadasErro;
        private static long startTiks = 0;
        private static long endTiks = 0;
        private static double segundosProcessamento;
        private static StringBuilder sb;


        public static int ObterNrLinhasProcessadasSucesso
        {
            get{return nrLinhasProcessadasSucesso;}
        }

        public static int ObterNrLinhasProcessadasErro
        {
            get { return nrLinhasProcessadasErro; }
        }
        public static int ObterPercentualProcessado()
        {
            return (int)(((float)nrLinhasProcessadas / (float)nrTotalLinhas) * 100);
        }

        public static double TempoProcessamento
        {
            get { return segundosProcessamento; }
        }
        public static int TotalLinhas
        {
            get { return nrTotalLinhas; }
        }

        public static int LinhasProcessadas
        {
            get { return nrLinhasProcessadas; }
        }
        private void ContaLinhas(string arquivo)
        {
            nrTotalLinhas = arquivo.Split('\n').Length;
        }

        private void ProcessaLinha(string linha)
        {
            Comando cmd = new Comando();
            cmd.AbreTransacao();
            
                if (linha.Contains(';'))
                {
                    lock ((object)nrLinhasProcessadas)
                    {
                        nrLinhasProcessadas++;
                    }
                    
                    string[] conteudoLinha = linha.Split(';');
                    decimal valor;

                    try
                    {
                        if (conteudoLinha.Length == 4)
                        {
                            cmd.InsereProduto(Int64.Parse(conteudoLinha[0]), conteudoLinha[1], conteudoLinha[2], decimal.TryParse(conteudoLinha[3], out valor) ? valor : 0);
                            nrLinhasProcessadasSucesso++;
                        }
                        else
                        {
                            sb.AppendLine(string.Format("linha: {0} - fora de padrao", linha[0]));
                            nrLinhasProcessadasErro++;
                        }
                    }
                    catch (Exception ex)
                    {
                        sb.AppendLine(string.Format("Erro ao lera a linha: {0} - erro: {1}", linha[0], ex.Message));
                        cmd.CancelaTransacao();

                    }
                    
                }
            
            
            cmd.FechaTransacao();
        }
        private void AtualizaLinhasProcessadas()
        {
            lock (this)
            {
                nrLinhasProcessadas++;
            }
        }
        private void AtualizaLinhasProcessadasSucesso()
        {
            lock (this)
            {
                nrLinhasProcessadasSucesso++;
            }
        }
        private void AtualizaLinhasProcessadasErro()
        {
            lock (this)
            {
                nrLinhasProcessadasErro++;
            }
        }
        private void ProcessaLinhas(string[] linhas,int idxInicio, int idxFim)
        {
            Comando cmd = new Comando();
            cmd.AbreTransacao();
            idxFim = idxFim > linhas.Length ? linhas.Length : idxFim;

            for(int i=idxInicio;i<idxFim;i++)
            {
                AtualizaLinhasProcessadas();
                    
                try
                {
                    if (linhas[i].Contains(';'))
                    {

                        //Todo: inserir linha
                        string[] conteudoLinha = linhas[i].Split(';');
                        decimal valor;

                        if (conteudoLinha.Length == 4)
                        {
                            cmd.InsereProduto(Int64.Parse(conteudoLinha[0]), conteudoLinha[1], conteudoLinha[2], decimal.TryParse(conteudoLinha[3], out valor) ? valor : 0);
                            AtualizaLinhasProcessadasSucesso();
                                

                        }
                        else
                        {
                            sb.AppendLine(string.Format("linha: {0} - fora de padrao", i));
                            AtualizaLinhasProcessadasErro();
                                
                        }
                    }
                }
                catch (Exception ex)
                {
                    sb.AppendLine(string.Format("Erro ao lera a linha: {0} - erro: {1}", i, ex.Message));
                    cmd.CancelaTransacao();

                }

            }
            cmd.FechaTransacao();
        }

        public  void ImportarArqvuivo(Stream arquivo, decimal fracaoIdeal)
        {
            sb = new StringBuilder();
            startTiks = DateTime.Now.Ticks;
            nrLinhasProcessadas = 0;
            nrTotalLinhas = 0;
            segundosProcessamento = 0;
            nrLinhasProcessadasSucesso = 0;
            nrLinhasProcessadasErro = 0;

            StreamReader sr = new StreamReader(arquivo);
            string strArquivo = sr.ReadToEnd();
            sr.Close();
            sr.Dispose();

            ContaLinhas(strArquivo);
            
            string[] linhas = strArquivo.Split('\n');

            

            List<Thread> threads = new List<Thread>();


            int nrTrheds = ((linhas.Length * fracaoIdeal) % 100) > 0 ? (int)((linhas.Length * fracaoIdeal) / 100) + 1 : (int)((linhas.Length * fracaoIdeal) / 100);
            sb.AppendLine("numero de threads: " + nrTrheds);
            int idxLinhaInicio = 0;
            int baseLeitura = linhas.Length % nrTrheds > 0 ? (linhas.Length / nrTrheds) + 1 : (linhas.Length / nrTrheds);
            int idxbase = baseLeitura;
            int idxLinhaFim = idxbase;
            //int nrTrheds = linhas.Length % idxLinhaFim > 0 ? (linhas.Length / idxLinhaFim) + 1 : (linhas.Length / idxLinhaFim);


            for (int idxThread = 0; idxThread < nrTrheds; idxThread++)
            {
                int temp1 = idxLinhaInicio;
                int temp2 = idxLinhaFim;
                threads.Add(new Thread(() => ProcessaLinhas(linhas,temp1,temp2)));
                
                threads[idxThread].Start();

                if (idxThread < nrTrheds - 1)
                {
                    idxLinhaInicio = idxLinhaFim;
                    idxLinhaFim = idxLinhaFim + idxbase;
                }
                
                
            }

            foreach (Thread t in threads)
            {
                t.Join();
            }

            


  /*          Thread t1 = new Thread(() => ProcessaLinhas(linhas, 0, 5000));
            Thread t2 = new Thread(() => ProcessaLinhas(linhas, 5001, linhas.Length));
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();
            */
            //if(ProcessaLinhas(linhas, 0, linhas.Length, cmd))
                //Todo: Comitar e fechar trasacao
            
            
            
            
            
            
            endTiks = DateTime.Now.Ticks;
            segundosProcessamento = TimeSpan.FromTicks(endTiks - startTiks).TotalSeconds;
            
        }
    }
}

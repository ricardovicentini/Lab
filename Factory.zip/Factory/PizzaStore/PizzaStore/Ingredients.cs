﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    public interface Douhg
    {
        string Name { get; }
    }

    public interface Sauce
    {
        string Name { get; }
    }

    public interface Cheese
    {
        string Name { get; }
    }

    public interface Veggie
    {
        string Name { get; }
    }

    public interface Pepperoni
    {
        string Name { get; set; }
    }

    public interface Clam
    {
        string Name { get; }
    }

    public class ThickCrustDough : Douhg
    {
        public string Name
        {
            get
            {
                return "ThickCrustDough";
            }
            
        }
    }

    public class ThinCrustDough : Douhg
    {
        public string Name
        {
            get { return "Thin Crust Dough"; }
        }
    }

    public class PlumTomatoSauce : Sauce
    {
        public string Name
        {
            get { return "Plum Tomato Sauce"; }
        }
    }

    public class MarinaraSauce : Sauce
    {
        public string Name
        {
            get { return "Marinara Sauce"; }
        }
    }


    public class MozzarelaCheese : Cheese
    {
        public string Name
        {
            get { return "Mozzarela cheese"; }
        }
    }

    public class ReggianoCheese : Cheese
    {
        public string Name
        {
            get { return "Reggiano cheese"; }
        }
    }

    public class FrozenClam : Clam
    {
        public string Name
        {
            get { return "Frozen clam"; }
        }
    }

    public class FreshClam : Clam
    {
        public string Name
        {
            get { return "Fresh clam"; }
        }
    }

    public class Onion : Veggie
    {
        public string Name
        {
            get { return "Onion"; }
        }
    }

    public class Garlic : Veggie
    {
        public string Name
        {
            get { return "Garlic"; }
        }
    }

    public class Mushroom : Veggie
    {
        public string Name
        {
            get { return "Mushroom"; }
        }
    }

    public class RedPepper : Veggie
    {

        public string Name
        {
            get { return "Red pepper"; }
        }
    }

    public class SlicedPepperoni : Pepperoni
    {
        public string Name
        {
            get
            {
                return "Sliced Pepperoni";
            }
            set
            {
                throw new NotImplementedException();
            }
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzaStore
{
    class CAPizzaStore : PizzaStore
    {
        public override iPizza CreatePizza(string item)
        {
            switch (item)
            {
                case "chesse":
                    return new CAStyleChessePizza();
                case "veggie":
                    return new CAStyleVeggiePizza();
                case "clam":
                    return new CAStyleClamPizza();
                case "peperoni":
                    return new CAStylepeperoniPizza();
                default:
                    throw new Exception("Pizza não encontrada");
            }
        }

        public override Pizza CreatePizzaV2(string type)
        {
            throw new NotImplementedException();
        }
    }
}

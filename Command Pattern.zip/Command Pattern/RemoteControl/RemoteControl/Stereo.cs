﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class Stereo
    {
        public void On()
        {
            Console.WriteLine("Stereo is on!");
        }

        public void SetCD()
        {
            Console.WriteLine("CD is set!");
        }

        public void SetDVD()
        {
            Console.WriteLine("DVD is set!");
        }

        public void SetRadio()
        {
            Console.WriteLine("Radio is set!");
        }

        public void SetVolume(int vol)
        {
            Console.WriteLine(string.Format("Volume is set to {0}!",vol));
        }

        public void Off()
        {
            Console.WriteLine("Stereo is off!");
        }

    }
}

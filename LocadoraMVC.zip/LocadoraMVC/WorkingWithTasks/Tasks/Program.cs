﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Tasks
{
    public class CustomData
    {
        public string Name { get; set; }
        public long CreationTime { get; set; }
        public int ThreadNum { get; set; }
        
    }

    class Program
    {
        static void Main(string[] args)
        {
            #region exemplo 1
            //Thread.CurrentThread.Name = "Main";

            ////Create a task and supply a user delegate by using a lambda expression
            //Task taskA = new Task(() => Console.WriteLine("Hello from taskA"));
            ////start the task
            //taskA.Start();

            ////Output a message from the calling thread
            //Console.WriteLine("Hello from thread '{0}'.", Thread.CurrentThread.Name);

            //taskA.Wait();
            #endregion

            Task[] taskArray = new Task[10];
            for (int i=0; i < taskArray.Length; i++)
            {
                taskArray[i] = Task.Factory.StartNew(
                                                (Object obj) =>
                                                {
                                                    //var data = new CustomData() { Name = i.ToString(), CreationTime = DateTime.Now.Ticks };
                                                    CustomData data = obj as CustomData;
                                                    if(data == null)
                                                        return;

                                                    data.ThreadNum = Thread.CurrentThread.ManagedThreadId;
                                                    Console.WriteLine("Task #{0} created at {1} on thread #{2}.",
                                                               data.Name, data.CreationTime, data.ThreadNum);
                                                },
                                                new CustomData(){ Name = i.ToString(), CreationTime = DateTime.Now.Ticks});
            }
            Task.WaitAll(taskArray);
        }
    }
}

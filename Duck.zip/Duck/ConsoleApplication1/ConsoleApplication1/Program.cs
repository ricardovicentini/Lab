﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program2
    {
        static void Main(string[] args)
        {
            Duck mallard = new MallardDuck();
            mallard.flyBehavior = new FlyWithWings();
            mallard.quackBehavior = new Quack();
            
            mallard.PerformQuack();
            mallard.PerformFly();


            Duck model = new ModelDuck();
            model.PerformFly();
            ((ModelDuck)model).setFlyBehavior(new FlyRocketPowered());
            model.PerformFly();
            
        }
    }
}

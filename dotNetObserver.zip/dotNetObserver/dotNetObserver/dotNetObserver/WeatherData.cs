﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dotNetObserver
{
    //public delegate void MesurementChangedEventHandler(float temperature, float humidity, float pressure);
    
    public class WeatherData : ISubject
    {
        

        public float getTemperature { get; set; }
        public float getHumidity { get; set; }
        public float getPressure { get; set; }

        //public event MesurementChangedEventHandler MesurementChanged;

        public virtual void OnMesurementChanged(float temperature, float humidity, float pressure)
        {
            if (MesurementChanged != null)
            {
                getTemperature = temperature;
                getHumidity = humidity;
                getPressure = pressure;
                this.MesurementChanged(temperature, humidity, pressure);
            }
        }

        public event MesurementChangedEventHandler MesurementChanged;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RemoteControl
{
    public class GarageDorCloseCommand : iCommand
    {
        GarageDoor garageDoor;
        public GarageDorCloseCommand(GarageDoor garageDoor_)
        {
            garageDoor = garageDoor_;
        }

        public void Execute()
        {
            garageDoor.Down();
        }


        public void Undo()
        {
            garageDoor.Up();
        }
    }
}

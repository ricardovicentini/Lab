﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class FlyWithWings : FlyBehavior
    {

        public void Fly()
        {
            Console.WriteLine("I'm flying!");
        }
    }
}
